$param = @{
   EmpNo='DailyClearBatch'
}
$json = $param | ConvertTo-Json
$response = Invoke-RestMethod 'http://localhost/api/emplocation/ClearEmpLocationInfo' -Method Delete -Body $json -ContentType 'application/json'